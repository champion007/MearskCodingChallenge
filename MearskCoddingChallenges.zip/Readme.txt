Maersk
how to setup the code into local machine -

#1 Clone repository / Extract the zip file
#2 Run - npm install.
#3 Add platform - ionic cordova platform add ios/android
#4 Deploy the build to iOS/Android - ionic cordova build ios/android
#5 serve on the web browser simulator - ionic serve

Note -

There are two tabs
First tab

a. File download, where you can enter valid file path URL and click download.
b. File transfer will be shown in the percentage.

Second tab

a. Open Weather, where you can enter a valid city name and click Fetch Weather to get the weather result.
b. Search History will be displayed for searched cities.
c. throws error if city detail is not listed to OpenWeather API.
d. One can click on the search history city name to get the weather details

Happy coding...😊